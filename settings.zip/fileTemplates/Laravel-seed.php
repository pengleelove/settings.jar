<?php
class ${NAME} extends Seeder {
	
	public function run() {
		
	}
}